"""
SQL tool for generating SQL queries from pandas dataframes and natural language questions.
"""

import re
from typing import Any, Dict, Optional

import pandas as pd
import sqlglot
from pydantic import BaseModel, field_validator

from ..chains.simple import SimpleChain
from ..core.exceptions import SQLValidationError
from ..core.interface import LLMInterface
from ..prompts.sql import SQL_GENERATION_PROMPT


class SQLResponse(BaseModel):
  """Response model for SQL query generation."""
  query: str

  @field_validator('query')
  @classmethod
  def validate_sql_query(cls, v: str) -> str:
    """
    Validate that the query string contains a valid SQL query using sqlglot.
    """
    if not v or not v.strip():
      raise SQLValidationError("SQL query cannot be empty")

    query = v.strip()

    try:
      # Parse the SQL to check syntax
      parsed = sqlglot.parse_one(query)

      if parsed is None:
        raise SQLValidationError("Empty SQL query")

      # Remove trailing semicolon if present
      if query.endswith(';'):
        query = query[:-1].strip()

      return query

    except sqlglot.ParseError as e:
      raise SQLValidationError(f"Invalid SQL syntax: {e}")
    except Exception as e:
      raise SQLValidationError(f"SQL validation error: {e}")


def create_sql_chain(
    dataframe: pd.DataFrame,
    table_name: str,
    provider_name: str,
    provider_settings: Optional[Dict[str, Any]] = None,
    max_sample_rows: int = 5,
    max_categorical_values: int = 10,
    max_columns: int = 50,
) -> SimpleChain:
  """
  Create a SimpleChain configured specifically for SQL generation for a given dataframe.

  This function analyzes the dataframe structure and creates a chain with a system prompt
  that includes the table schema and sample data. The chain can then be used to generate
  SQL queries for different questions about the same dataframe.

  Args:
      dataframe: The pandas DataFrame to analyze
      table_name: The name of the table to use in SQL queries
      provider_name: Name of the LLM provider to use
      provider_settings: Optional provider-specific settings
      max_sample_rows: Number of sample rows to include in the prompt (default: 5)
      max_categorical_values: Maximum number of categorical values to show per column (default: 10)
      max_columns: Maximum number of columns to include in schema (default: 50)

  Returns:
      A SimpleChain configured for SQL generation with the dataframe context

  Raises:
      ValueError: If the dataframe is empty or invalid
  """
  if dataframe.empty:
    raise ValueError("DataFrame cannot be empty")

  # Generate table schema description
  table_schema = _generate_table_schema(dataframe, max_categorical_values, max_columns)

  # Generate sample data
  categorical_section, sample_rows_section = _generate_sample_data(
    dataframe, max_sample_rows, max_categorical_values)

  # Create the system prompt using Langchain template
  system_prompt = SQL_GENERATION_PROMPT.format(
      table_name=table_name,
      table_schema=table_schema,
      categorical_summaries=categorical_section,
      sample_rows=sample_rows_section,
  )

  return LLMInterface.create(
      provider_name=provider_name,
      settings=provider_settings,
      output_format=SQLResponse,
      system_prompt=system_prompt,
  )


def _generate_table_schema(dataframe: pd.DataFrame, max_categorical_values: int = 10, max_columns: int = 50) -> str:
  """Generate a table schema description from a pandas DataFrame."""
  schema_lines = []

  # Limit columns for very large dataframes
  columns_to_process = dataframe.columns[:max_columns] if len(
    dataframe.columns) > max_columns else dataframe.columns

  for column in columns_to_process:
    dtype = dataframe[column].dtype
    # Determine SQL type based on pandas dtype
    sql_type = _pandas_to_sql_type(dtype)

    # Add column with SQL type (no categorical examples here)
    schema_lines.append(f"{column} {sql_type}")

  if len(dataframe.columns) > max_columns:
    schema_lines.append(f"... and {len(dataframe.columns) - max_columns} more columns")

  return "\n".join(schema_lines)


def _generate_sample_data(
    dataframe: pd.DataFrame,
    max_sample_rows: int,
    max_categorical_values: int,
) -> tuple[str, str]:
  """Generate sample data description for the prompt."""
  if dataframe.empty:
    return "No data available", "No data available"

  # Sample rows
  sample_df = dataframe.head(max_sample_rows)

  # Generate categorical value summaries
  categorical_summaries = []
  for column in dataframe.columns:
    if dataframe[column].dtype == 'object' or dataframe[column].dtype.name == 'category':
      unique_values = dataframe[column].dropna().unique()
      if len(unique_values) <= 20:  # Only summarize for reasonable number of categories
        top_values = list(unique_values[:max_categorical_values])
        categorical_summaries.append(f"{column}: {top_values}")

  categorical_section = "\n".join(
    categorical_summaries) if categorical_summaries else "No categorical columns"

  # Generate sample rows
  sample_lines = []
  for idx, row in sample_df.iterrows():
    row_data = []
    for col, value in row.items():
      # Truncate long values
      if isinstance(value, str) and len(str(value)) > 50:
        value = str(value)[:50] + "..."
      row_data.append(f"{col}={value}")
    sample_lines.append(f"Row {idx}: {', '.join(row_data)}")

  sample_rows_section = "\n".join(sample_lines)

  return categorical_section, sample_rows_section


def _pandas_to_sql_type(dtype) -> str:
  """Convert pandas dtype to SQL type."""
  dtype_str = str(dtype)

  if 'int' in dtype_str:
    return 'INT'
  elif 'float' in dtype_str:
    return 'FLOAT'
  elif 'bool' in dtype_str:
    return 'BOOLEAN'
  elif 'datetime' in dtype_str:
    return 'TIMESTAMP'
  elif 'date' in dtype_str:
    return 'DATE'
  else:
    return 'TEXT'
