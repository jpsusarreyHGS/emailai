import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Type, Union

from dotenv import load_dotenv
from langchain_core.messages import HumanMessage
from pydantic import BaseModel

from .image import encode_image_to_data_uri, validate_image_file


def load_settings_from_env_and_dict(
    settings_class: Type[BaseModel],
    explicit_settings: Optional[Dict[str, Any]] = None
) -> Tuple[BaseModel, Dict[str, Any]]:
  """Load settings from environment variables and explicit dictionary.

  Returns:
      Tuple of (validated_settings, extra_settings) where extra_settings contains
      any settings not defined in the settings_class that should be passed through
      to the LangChain client.
  """
  load_dotenv()

  # Start with environment variables
  env_settings = {}
  for field_name, field in settings_class.model_fields.items():
    env_alias = field.alias
    if env_alias and os.getenv(env_alias):
      env_settings[env_alias] = os.getenv(env_alias)

  # Track which settings are provider-specific vs extra
  provider_settings = {}
  extra_settings = {}

  # Override with explicit settings if provided
  if explicit_settings:
    for key, value in explicit_settings.items():
      # Check if this key corresponds to a provider-specific field
      is_provider_setting = False
      for field_name, field in settings_class.model_fields.items():
        if key == field_name or (field.alias and key == field.alias):
          provider_settings[field.alias or field_name] = value
          is_provider_setting = True
          break

      # If not a provider setting, it's an extra setting to pass through
      if not is_provider_setting:
        extra_settings[key] = value

  # Add environment variables to provider settings
  for field_name, field in settings_class.model_fields.items():
    env_alias = field.alias
    if env_alias and env_alias in env_settings:
      provider_settings[env_alias] = env_settings[env_alias]

  # Create and validate the settings object
  validated_settings = settings_class(**provider_settings)

  return validated_settings, extra_settings


def build_multimodal_input(prompt: str, images: Union[str, Path, List[Union[str, Path]]]) -> HumanMessage:
  """
  Build a multimodal input with text and images for LangChain providers.

  Args:
      prompt: The text prompt to send
      images: Single image path or list of image paths (string or Path objects)

  Returns:
      HumanMessage object with text and image content

  Raises:
      FileNotFoundError: If any image file doesn't exist
      ValueError: If MIME type cannot be determined for any image
  """
  # Convert single image to list for consistent handling
  if isinstance(images, (str, Path)):
    images = [images]

  # Validate and encode all images
  image_paths = []
  for img in images:
    img_path = Path(img)
    if not validate_image_file(img_path):
      raise FileNotFoundError(f"Invalid or missing image file: {img_path}")
    image_paths.append(str(img_path))

  # Build the content list starting with text
  content: List[Union[str, Dict[str, Any]]] = [{"type": "text", "text": prompt}]

  # Add encoded images
  for path in image_paths:
    data_uri = encode_image_to_data_uri(path)
    content.append({
        "type": "image_url",
        "image_url": {
            "url": data_uri,
            "detail": "auto"
        }
    })

  # Return a HumanMessage object
  return HumanMessage(content=content)
