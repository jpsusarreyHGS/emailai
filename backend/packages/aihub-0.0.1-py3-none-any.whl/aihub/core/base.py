import os
from abc import ABC, abstractmethod
from typing import Any, Dict, Generic, Optional, TypeVar

from langchain_core.runnables import Runnable
from pydantic import BaseModel, model_validator


class BaseSettings(BaseModel):
  """Base settings class with common functionality."""
  class Config:
    env_file = ".env"
    env_file_encoding = "utf-8"
    case_sensitive = False

  @model_validator(mode="after")
  def no_empty_strings(cls, values):
    for field_name, value in values.__dict__.items():
      if isinstance(value, str) and not value.strip():
        raise ValueError(f"{field_name} cannot be an empty string")
    return values


T = TypeVar('T', bound=BaseSettings)


class BaseLLMProvider(ABC, Generic[T]):
  def __init__(self, settings: T, extra_settings: Optional[Dict[str, Any]] = None):
    self.settings = settings
    self.extra_settings = extra_settings or {}
    self.client: Runnable | None = None

  @abstractmethod
  def get_client(self) -> Runnable:
    pass


class BaseChain(ABC):
  def __init__(self, provider: BaseLLMProvider):
    self.provider = provider

  @abstractmethod
  def generate(self, prompt: str) -> BaseModel:
    pass
