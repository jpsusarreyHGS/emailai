from .azure_openai import AzureOpenAIEmbeddingsProvider, AzureOpenAIProvider
from .bedrock import BedrockEmbeddingsProvider, BedrockProvider
from .openai import OpenAIEmbeddingsProvider, OpenAIProvider

PROVIDER_REGISTRY = {
    "azure-openai": AzureOpenAIProvider,
    "openai": OpenAIProvider,
    "bedrock": BedrockProvider,
}

EMBEDDINGS_PROVIDER_REGISTRY = {
    "azure-openai": AzureOpenAIEmbeddingsProvider,
    "openai": OpenAIEmbeddingsProvider,
    "bedrock": BedrockEmbeddingsProvider,
}


def get_provider(name: str):
  try:
    return PROVIDER_REGISTRY[name]
  except KeyError:
    raise ValueError(f"Unknown provider: {name}")


def get_embeddings_provider(name: str):
  try:
    return EMBEDDINGS_PROVIDER_REGISTRY[name]
  except KeyError:
    raise ValueError(f"Unknown embeddings provider: {name}")
