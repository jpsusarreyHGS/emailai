from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, ValidationError

from ..core.base import BaseChain
from ..core.exceptions import (
    InputProcessingError,
    ProviderCommunicationError,
    ResponseParsingError,
    ResponseValidationError,
)
from ..utils.input import build_multimodal_input


class DefaultOutputFormat(BaseModel):
  """Default output format for simple chains with a single content field."""
  content: str


class SimpleChain(BaseChain):
  """
  A simple chain that provides structured LLM generation.

  This chain wraps an LLM provider and binds a Pydantic schema for structured output.
  It supports both text-only and multimodal (text + images) inputs, and maintains
  conversation history for contextual responses.

  Attributes:
      provider: The LLM provider instance
      output_format: The Pydantic schema class for structured output
      chat_history: List of conversation messages for context
  """

  def __init__(
      self,
      provider,
      output_format: Optional[type[BaseModel]] = DefaultOutputFormat,
      chat_history: Optional[List[Tuple[str, str]]] = None,
      system_prompt: Optional[str] = None
  ):
    """
    Initialize a SimpleChain with a provider and output format.

    Args:
        provider: The LLM provider instance
        output_format: Pydantic schema class that defines the expected output structure.
            If None, defaults to DefaultOutputFormat. The LLM will be constrained to return 
            data matching this schema.
        chat_history: Optional list of (role, content) tuples representing previous
            conversation turns. Roles can be "user", "assistant", or "system".
        system_prompt: Optional system prompt to prepend to the chat history as the first
            message. If provided, this will be added as a "system" role message at the
            beginning of the conversation.

    Raises:
        ValueError: If an unknown role is provided in chat_history.
    """
    super().__init__(provider)

    # Bind the output format to the provider client
    if output_format is None:
      output_format = DefaultOutputFormat
    self.provider.client = self.provider.client.bind_tools(
      [output_format], tool_choice="any")
    self.output_format = output_format

    # Prepend system prompt to chat history if provided
    if system_prompt:
      if chat_history is None:
        chat_history = []
      chat_history = [("system", system_prompt)] + chat_history

    # Assemble chat history of BaseMessage objects from the provided chat history
    self.chat_history: List[BaseMessage] = []
    if chat_history:
      for role, content in chat_history:
        if role == "user":
          self.chat_history.append(HumanMessage(content=content))
        elif role == "assistant":
          self.chat_history.append(AIMessage(content=content))
        elif role == "system":
          self.chat_history.append(SystemMessage(content=content))
        else:
          raise ValueError(f"Unknown role in chat_history: {role}")

  def generate(
      self,
      prompt: str,
      images: Optional[Union[str, Path, List[Union[str, Path]]]] = None
  ) -> BaseModel:
    """
    Generate a structured response based on the prompt and optional images.

    This method sends the prompt (and images if provided) to the LLM and returns
    a validated Pydantic object matching the output_format schema. The response
    is automatically added to the chat history for future context.

    Args:
        prompt: The text prompt to send to the LLM 
        images: Image(s) to include with the prompt. Can be a single image path (str or
            Path), a list of image paths, or None for text-only prompts.

    Returns:
        A validated Pydantic object matching the output_format schema. If no 
        output_format is provided, this will have a single 'content' text field.

    Raises:
        RuntimeError: If the provider client is not initialized or if the
            provider returns an unexpected response type.
        ProviderCommunicationError: If there's an error communicating with the LLM provider.
        InputProcessingError: If there's an error processing the input (e.g., building multimodal messages).
        ResponseValidationError: If the LLM response cannot be validated against the output format schema.
        ResponseParsingError: If there's an error parsing the LLM response.
    """
    if self.provider.client is None:
      raise RuntimeError("Provider client is not initialized")

    # Add the current user message (with or without images)
    try:
      if images:
        current_message = build_multimodal_input(prompt, images)
      else:
        current_message = HumanMessage(content=prompt)
      self.chat_history.append(current_message)
    except Exception as e:
      raise InputProcessingError(f"Failed to build input message: {e}") from e

    # Generate the response
    try:
      response = self.provider.client.invoke(self.chat_history)
    except Exception as e:
      # Remove the current message from history since the request failed
      if self.chat_history:
        self.chat_history.pop()
      provider_name = self.provider.__class__.__name__
      raise ProviderCommunicationError(
        f"{provider_name} provider failed to generate response: {e}") from e

    # Validate that the invocation returned an AIMessage
    if not isinstance(response, AIMessage):
      provider_name = self.provider.__class__.__name__
      raise RuntimeError(
          f"{provider_name} provider returned {type(response).__name__}, expected AIMessage: {response}")

    # Extract the structured data from the response
    try:
      structured_data = response.tool_calls[0]['args']
      validated_response = self.output_format.model_validate(structured_data)
    except ValidationError as e:
      raise ResponseValidationError(
        f"Failed to validate response against output format: {e}") from e
    except Exception as e:
      raise ResponseParsingError(f"Failed to parse response: {e}") from e

    # Create a clean AIMessage for chat history (without tool calls)
    history_content = str(validated_response.model_dump())
    clean_response = AIMessage(content=history_content)
    self.chat_history.append(clean_response)

    return validated_response
