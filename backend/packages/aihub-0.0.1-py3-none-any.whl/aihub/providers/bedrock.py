from typing import Any, Dict, Optional

from langchain_aws import BedrockEmbeddings, ChatBedrockConverse
from langchain_core.runnables import Runnable
from pydantic import Field, field_validator

from ..core.base import BaseLLMProvider, BaseSettings
from ..core.exceptions import ProviderInitializationError
from ..utils.input import load_settings_from_env_and_dict


class BedrockSettings(BaseSettings):
  """Settings for AWS Bedrock provider."""
  model_id: str = Field(..., alias="BEDROCK_MODEL")
  region_name: str = Field(..., alias="AWS_REGION")
  aws_access_key_id: Optional[str] = Field(default=None, alias="AWS_ACCESS_KEY_ID")
  aws_secret_access_key: Optional[str] = Field(
    default=None, alias="AWS_SECRET_ACCESS_KEY")
  aws_session_token: Optional[str] = Field(default=None, alias="AWS_SESSION_TOKEN")


class BedrockProvider(BaseLLMProvider[BedrockSettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      BedrockSettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "model_id": self.settings.model_id,
          "region_name": self.settings.region_name,
      }

      # Add AWS credentials if provided
      if self.settings.aws_access_key_id and self.settings.aws_secret_access_key:
        client_kwargs.update({
          "aws_access_key_id": self.settings.aws_access_key_id,
          "aws_secret_access_key": self.settings.aws_secret_access_key,
        })

        # Add session token if provided (only when credentials are provided)
        if self.settings.aws_session_token:
          client_kwargs["aws_session_token"] = self.settings.aws_session_token

      # Add any extra settings (like temperature, max_tokens, etc.)
      client_kwargs.update(self.extra_settings)

      return ChatBedrockConverse(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(f"Failed to instantiate Bedrock client: {e}")


class BedrockEmbeddingsSettings(BaseSettings):
  """Settings for AWS Bedrock embeddings provider."""
  model_id: str = Field(..., alias="BEDROCK_EMBEDDINGS_MODEL")
  region_name: str = Field(..., alias="AWS_EMBEDDINGS_REGION")
  aws_access_key_id: Optional[str] = Field(default=None, alias="AWS_EMBEDDINGS_ACCESS_KEY_ID")
  aws_secret_access_key: Optional[str] = Field(
    default=None, alias="AWS_EMBEDDINGS_SECRET_ACCESS_KEY")
  aws_session_token: Optional[str] = Field(default=None, alias="AWS_EMBEDDINGS_SESSION_TOKEN")
  dimensions: Optional[int] = Field(None, alias="BEDROCK_EMBEDDINGS_DIMENSIONS")

  @field_validator('dimensions')
  @classmethod
  def validate_dimensions(cls, v):
    if v is not None and v not in [256, 512, 1024]:
      raise ValueError(
        'Dimensions for the Titan Text Embeddings model must be one of: 256, 512, or 1024')
    return v


class BedrockEmbeddingsProvider(BaseLLMProvider[BedrockEmbeddingsSettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      BedrockEmbeddingsSettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "model_id": self.settings.model_id,
          "region_name": self.settings.region_name,
      }

      # Add AWS credentials if provided
      if self.settings.aws_access_key_id and self.settings.aws_secret_access_key:
        client_kwargs.update({
          "aws_access_key_id": self.settings.aws_access_key_id,
          "aws_secret_access_key": self.settings.aws_secret_access_key,
        })

        # Add session token if provided (only when credentials are provided)
        if self.settings.aws_session_token:
          client_kwargs["aws_session_token"] = self.settings.aws_session_token

      # Add dimensions if specified
      if self.settings.dimensions is not None:
        client_kwargs["model_kwargs"] = {"dimensions": self.settings.dimensions}

      # Add any extra settings
      client_kwargs.update(self.extra_settings)

      return BedrockEmbeddings(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(f"Failed to instantiate Bedrock embeddings client: {e}")
