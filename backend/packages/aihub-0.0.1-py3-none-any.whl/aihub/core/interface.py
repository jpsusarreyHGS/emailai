from typing import Any, Dict, List, Optional, Tuple, Type, Union

from pydantic import BaseModel

from ..chains.embeddings import EmbeddingsChain
from ..chains.simple import SimpleChain
from ..providers.registry import get_embeddings_provider, get_provider


class LLMInterface:
  """
  Main interface for creating LLM chains with structured output.

  This class provides a simple factory method to create LLM chains with
  various providers, output formats, and optional chat history.
  """

  @staticmethod
  def create(
      provider_name: str,
      settings: Dict[str, Any] | None = None,
      output_format: Optional[Type[BaseModel]] = None,
      chat_history: Optional[List[Tuple[str, str]]] = None,
      system_prompt: Optional[str] = None
  ) -> SimpleChain:
    '''Create a LLM chain object with the specified provider and configuration.

    This is the main entry point for creating LLM chains. It automatically
    handles provider initialization, output format binding, and chat history setup.

    Args:
        provider_name: Name of the LLM provider to use (e.g., "openai", "azure-openai")
        settings: Optional dictionary of provider-specific settings. If None, settings 
            will be loaded from environment variables.
        output_format: Pydantic schema class that defines the expected output structure.
            If None, defaults to a single 'content' field. The LLM will be constrained to return 
            data matching this schema.
        chat_history: Optional list of (role, content) tuples representing previous
            conversation turns. Roles can be "user", "assistant", or "system".
            Useful for maintaining context across multiple interactions.
        system_prompt: Optional system prompt to prepend to the chat history as the first
            message. If provided, this will be added as a "system" role message at the
            beginning of the conversation. Submitting a chat history with a single 'system'
            type message would have the same effect.

    Returns:
        A configured chain instance ready for generation.

    Raises:
        ValueError: If an unknown provider name is provided or if an unknown role is specified in chat_history.
        ProviderInitializationError: If the provider fails to initialize.
    '''

    provider_class = get_provider(provider_name)
    provider = provider_class(settings)

    return SimpleChain(provider, output_format, chat_history, system_prompt)


class EmbeddingsInterface:
  """
  Main interface for creating embedding chains with multimodal support.

  This class provides a simple factory method to create embedding chains with
  various providers, supporting text and inputs with batch operations.
  """

  @staticmethod
  def create(
      provider_name: str,
      settings: Dict[str, Any] | None = None
  ) -> EmbeddingsChain:
    '''Create an embeddings chain object with the specified provider and configuration.

    This is the main entry point for creating embedding chains, automatically
    handling provider initialization.

    Args:
        provider_name: Name of the embeddings provider to use (e.g., "openai", "azure-openai")
        settings: Optional dictionary of provider-specific settings. If None, settings 
            will be loaded from environment variables.

    Returns:
        A configured embeddings chain instance ready for embedding generation.

    Raises:
        ValueError: If an unknown provider name is provided.
        ProviderInitializationError: If the provider fails to initialize.
    '''

    provider_class = get_embeddings_provider(provider_name)
    provider = provider_class(settings)

    return EmbeddingsChain(provider)
