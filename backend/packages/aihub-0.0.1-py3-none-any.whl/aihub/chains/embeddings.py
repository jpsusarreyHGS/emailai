from typing import List, Union

from pydantic import BaseModel

from ..core.base import BaseChain
from ..core.exceptions import ProviderCommunicationError


class EmbeddingsOutput(BaseModel):
  """Output schema for embeddings generation."""
  embeddings: List[List[float]]


class EmbeddingsChain(BaseChain):
  """
  A chain that provides embedding generation for text inputs.

  This chain wraps an embeddings provider and supports both single text and 
  batch text inputs for efficient embedding generation.

  Attributes:
      provider: The embeddings provider instance
  """

  def __init__(self, provider):
    """
    Initialize an EmbeddingsChain with a provider.

    Args:
        provider: The embeddings provider instance
    """
    super().__init__(provider)

  def generate(
      self,
      text: Union[str, List[str]]
  ) -> EmbeddingsOutput:
    """
    Generate embeddings for text input(s).

    This method automatically detects the input type and handles it appropriately:
    - Single text input: Returns a single embedding vector
    - Batch text input: Returns a list of embedding vectors

    Args:
        text: The text to embed. Can be a single string or a list of strings for batch processing.

    Returns:
        An EmbeddingsOutput instance containing the embedding vectors.

    Raises:
        RuntimeError: If the provider client is not initialized.
        ProviderCommunicationError: If there's an error communicating with the embeddings provider.
    """
    if self.provider.client is None:
      raise RuntimeError("Provider client is not initialized")

    try:
      # Handle batch text inputs
      if isinstance(text, list):
        embeddings = self.provider.client.embed_documents(text)
        return EmbeddingsOutput(embeddings=embeddings)

      # Handle single text input
      embeddings = self.provider.client.embed_query(text)
      # Wrap single embedding in a list to match the schema
      return EmbeddingsOutput(embeddings=[embeddings])

    except Exception as e:
      provider_name = self.provider.__class__.__name__
      raise ProviderCommunicationError(
        f"{provider_name} provider failed to generate embeddings: {e}") from e
