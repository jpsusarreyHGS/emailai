"""
Prompts module for AI task-specific prompts.
"""

from .sql import SQL_GENERATION_PROMPT

__all__ = [
    "SQL_GENERATION_PROMPT"
]
