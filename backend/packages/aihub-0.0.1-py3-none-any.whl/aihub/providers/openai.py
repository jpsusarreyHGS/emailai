from typing import Any, Dict, Optional

from langchain_core.runnables import Runnable
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from pydantic import Field, field_validator

from ..core.base import BaseLLMProvider, BaseSettings
from ..core.exceptions import ProviderInitializationError
from ..utils.input import load_settings_from_env_and_dict


class OpenAISettings(BaseSettings):
  """Settings for OpenAI provider."""
  api_key: str = Field(..., alias="OPENAI_API_KEY")
  model: str = Field(..., alias="OPENAI_MODEL")


class OpenAIProvider(BaseLLMProvider[OpenAISettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      OpenAISettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "api_key": self.settings.api_key,  # type: ignore
          "model": self.settings.model,
      }

      # Add any extra settings (like temperature, max_tokens, etc.)
      client_kwargs.update(self.extra_settings)

      return ChatOpenAI(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(f"Failed to instantiate OpenAI client: {e}")


class OpenAIEmbeddingsSettings(BaseSettings):
  """Settings for OpenAI embeddings provider."""
  api_key: str = Field(..., alias="OPENAI_EMBEDDINGS_API_KEY")
  model: str = Field(..., alias="OPENAI_EMBEDDINGS_MODEL")
  dimensions: Optional[int] = Field(None, alias="OPENAI_EMBEDDINGS_DIMENSIONS")

  @field_validator('dimensions')
  @classmethod
  def validate_dimensions(cls, v, info):
    if v is not None and v <= 0:
      raise ValueError('Dimensions must be a positive integer')

    # Check if model is available and contains 'text-embedding-ada-002'
    if v is not None and info.data and 'model' in info.data:
      model = info.data['model']
      if 'text-embedding-ada-002' in model:
        raise ValueError('text-embedding-ada-002 model does not support custom dimensions. Leave this field as None to use the default dimensions, or specify a different model that supports custom dimensions.')

    return v


class OpenAIEmbeddingsProvider(BaseLLMProvider[OpenAIEmbeddingsSettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      OpenAIEmbeddingsSettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "api_key": self.settings.api_key,  # type: ignore
          "model": self.settings.model,
      }

      # Add dimensions if specified
      if self.settings.dimensions is not None:
        client_kwargs["dimensions"] = self.settings.dimensions

      # Add any extra settings
      client_kwargs.update(self.extra_settings)

      return OpenAIEmbeddings(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(f"Failed to instantiate OpenAI embeddings client: {e}")
