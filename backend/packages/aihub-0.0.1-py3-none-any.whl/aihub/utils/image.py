import base64
import mimetypes
from pathlib import Path
from typing import Any, Dict, List, Union


def encode_image_to_data_uri(filepath: Union[str, Path]) -> str:
  """
  Encodes a local image file to a data URI with base64encoding.

  Args:
      filepath: Path to the image file (string or Path object)

  Returns:
      Data URI string in format: data:[object Object]mime_type};base64,{base64data}

  Raises:
      ValueError: If MIME type cannot be determined
      FileNotFoundError: If the image file doesn't exist
  """
  filepath = Path(filepath)

  if not filepath.exists():
    raise FileNotFoundError(f"Image file not found: {filepath}")

  # Guess MIME type (e.g. image/png or image/jpeg)
  mime_type, _ = mimetypes.guess_type(str(filepath))
  if mime_type is None:
    raise ValueError(f"Could not determine MIME type for {filepath}")
  # Read and encode the image
  with open(filepath, "rb") as f:
    b64 = base64.b64encode(f.read()).decode("utf-8")

  return f"data:{mime_type};base64,{b64}"


def validate_image_file(filepath: Union[str, Path]) -> bool:
  """
  Validates that a file exists and is a recognized image type.

  Args:
      filepath: Path to the image file

  Returns:
      True if the file is a valid image, False otherwise
  """
  filepath = Path(filepath)

  if not filepath.exists():
    return False

  mime_type, _ = mimetypes.guess_type(str(filepath))
  if mime_type is None:
    return False

  return mime_type.startswith("image/")
