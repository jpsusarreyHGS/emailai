class ProviderError(Exception):
  """Base exception for provider-related errors."""
  pass


class ProviderInitializationError(ProviderError):
  """Raised when a provider fails to initialize properly."""
  pass


class ProviderCommunicationError(ProviderError):
  """Raised when there's an error communicating with the LLM provider."""
  pass


class ChainExecutionError(Exception):
  """Base exception for chain execution errors."""
  pass


class InputProcessingError(ChainExecutionError):
  """Raised when there's an error processing input (e.g., building multimodal messages)."""
  pass


class ResponseValidationError(ChainExecutionError):
  """Raised when the LLM response cannot be validated against the expected schema."""
  pass


class ResponseParsingError(ChainExecutionError):
  """Raised when there's an error parsing the LLM response."""
  pass


class SQLValidationError(ChainExecutionError):
  """Raised when there's an error validating SQL queries."""
  pass
