from typing import Any, Dict, Optional, cast

from langchain_core.runnables import Runnable
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from pydantic import Field, field_validator

from ..core.base import BaseLLMProvider, BaseSettings
from ..core.exceptions import ProviderInitializationError
from ..utils.input import load_settings_from_env_and_dict


class AzureOpenAISettings(BaseSettings):
  """Settings for Azure OpenAI provider."""
  api_key: str = Field(..., alias="AZURE_OPENAI_API_KEY")
  endpoint: str = Field(..., alias="AZURE_OPENAI_ENDPOINT")
  deployment_name: str = Field(..., alias="AZURE_OPENAI_DEPLOYMENT")
  api_version: str = Field(..., alias="AZURE_OPENAI_API_VERSION")

  @field_validator('endpoint')
  @classmethod
  def validate_endpoint(cls, v):
    if not v.startswith('https://'):
      raise ValueError('Endpoint must be a valid HTTPS URL')
    return v.rstrip('/')


class AzureOpenAIProvider(BaseLLMProvider[AzureOpenAISettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    # Load and validate settings
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      AzureOpenAISettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "azure_deployment": self.settings.deployment_name,
          "azure_endpoint": self.settings.endpoint,
          "api_key": self.settings.api_key,  # type: ignore
          "api_version": self.settings.api_version,
      }

      # Add any extra settings (like temperature, max_tokens, etc.)
      client_kwargs.update(self.extra_settings)

      return AzureChatOpenAI(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(
        f"Failed to instantiate Azure OpenAI client: {e}")


class AzureOpenAIEmbeddingsSettings(BaseSettings):
  """Settings for Azure OpenAI embeddings provider."""
  api_key: str = Field(..., alias="AZURE_OPENAI_EMBEDDINGS_API_KEY")
  endpoint: str = Field(..., alias="AZURE_OPENAI_EMBEDDINGS_ENDPOINT")
  deployment_name: str = Field(..., alias="AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT")
  api_version: str = Field(..., alias="AZURE_OPENAI_EMBEDDINGS_API_VERSION")
  dimensions: Optional[int] = Field(None, alias="AZURE_OPENAI_EMBEDDINGS_DIMENSIONS")

  @field_validator('endpoint')
  @classmethod
  def validate_endpoint(cls, v):
    if not v.startswith('https://'):
      raise ValueError('Endpoint must be a valid HTTPS URL')
    return v.rstrip('/')

  @field_validator('dimensions')
  @classmethod
  def validate_dimensions(cls, v, info):
    if v is not None and v <= 0:
      raise ValueError('Dimensions must be a positive integer')

    # Check if deployment_name is available and contains 'text-embedding-ada-002'
    if v is not None and info.data and 'deployment_name' in info.data:
      deployment_name = info.data['deployment_name']
      if 'text-embedding-ada-002' in deployment_name:
        raise ValueError('text-embedding-ada-002 model does not support custom dimensions. Leave this field as None to use the default dimensions, or specify a different model that supports custom dimensions.')

    return v


class AzureOpenAIEmbeddingsProvider(BaseLLMProvider[AzureOpenAIEmbeddingsSettings]):
  def __init__(self, settings: Optional[Dict[str, Any]] = None):
    # Load and validate settings
    validated_settings, extra_settings = load_settings_from_env_and_dict(
      AzureOpenAIEmbeddingsSettings, settings)
    super().__init__(validated_settings, extra_settings)  # type: ignore
    self.client = self.get_client()

  def get_client(self) -> Runnable:
    try:
      client_kwargs = {
          "azure_deployment": self.settings.deployment_name,
          "azure_endpoint": self.settings.endpoint,
          "api_key": self.settings.api_key,  # type: ignore
          "api_version": self.settings.api_version,
      }

      # Add dimensions if specified
      if self.settings.dimensions is not None:
        client_kwargs["dimensions"] = self.settings.dimensions

      # Add any extra settings
      client_kwargs.update(self.extra_settings)

      return AzureOpenAIEmbeddings(**client_kwargs)
    except Exception as e:
      raise ProviderInitializationError(
        f"Failed to instantiate Azure OpenAI embeddings client: {e}")
