# llm_interface package

from .core.interface import EmbeddingsInterface, LLMInterface

__all__ = ["LLMInterface", "EmbeddingsInterface"]
